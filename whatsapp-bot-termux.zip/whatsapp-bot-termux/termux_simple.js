/**
 * Versi sederhana dari WhatsApp bot untuk Termux
 * Dirancang lebih ringan dan dengan fitur penting saja
 */

const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');

// Set folder penyimpanan
const authFolder = path.join(process.env.HOME || '.', '.wwebjs_auth');
if (!fs.existsSync(authFolder)) {
  fs.mkdirSync(authFolder, { recursive: true });
  console.log(`Folder otentikasi dibuat di: ${authFolder}`);
}

// Cari path Chromium
let chromePath = null;
if (process.env.PUPPETEER_EXECUTABLE_PATH) {
  chromePath = process.env.PUPPETEER_EXECUTABLE_PATH;
} else if (process.env.CHROME_PATH) {
  chromePath = process.env.CHROME_PATH;
} else {
  // Cek lokasi yang umum
  const possiblePaths = [
    '/data/data/com.termux/files/usr/bin/chromium-browser'
  ];
  
  for (const browserPath of possiblePaths) {
    if (fs.existsSync(browserPath)) {
      chromePath = browserPath;
      console.log(`Chromium ditemukan di: ${chromePath}`);
      break;
    }
  }
}

if (!chromePath) {
  console.error('KESALAHAN: Chromium tidak ditemukan. Pastikan Anda menginstal chromium di Termux');
  console.log('Gunakan: pkg install chromium');
  process.exit(1);
}

// Konfigurasi WhatsApp client untuk Termux
const client = new Client({
  authStrategy: new LocalAuth({
    clientId: 'whatsapp-termux-bot',
    dataPath: authFolder
  }),
  puppeteer: {
    executablePath: chromePath,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--disable-gpu',
      '--window-size=800x600'
    ],
    headless: 'new'
  }
});

// Handle QR code
client.on('qr', (qr) => {
  console.log('Scan QR code berikut dengan WhatsApp di ponsel Anda:');
  qrcode.generate(qr, { small: true });
  console.log('\nMenunggu pemindaian QR code...');
});

// Login status
client.on('loading_screen', (percent, message) => {
  console.log(`Memuat WhatsApp Web: ${percent}% - ${message}`);
});

client.on('authenticated', () => {
  console.log('Otentikasi berhasil!');
});

client.on('auth_failure', (error) => {
  console.error('Otentikasi gagal:', error);
});

client.on('ready', () => {
  console.log('WhatsApp bot sudah siap!');
  console.log('Ketik !help untuk melihat perintah yang tersedia');
});

// Handle pesan masuk
client.on('message', async (message) => {
  console.log(`Pesan diterima: ${message.body}`);
  
  // Hanya memproses pesan yang dimulai dengan tanda seru (!)
  if (message.body.startsWith('!')) {
    const command = message.body.split(' ')[0].toLowerCase();
    const args = message.body.substring(command.length).trim();
    
    switch (command) {
      case '!ping':
        message.reply('Pong! 🏓');
        break;
        
      case '!info':
        const info = await client.getInfo();
        message.reply(`*Info WhatsApp*\nNama: ${info.pushname}\nNomor: ${info.wid.user}\nPlatform: Termux Bot`);
        break;
        
      case '!help':
        message.reply(`*Perintah yang tersedia:*
!ping - Cek apakah bot aktif
!info - Tampilkan info WhatsApp
!creategroup <nama> <nomor1,nomor2,...> - Buat grup baru
!bulkmessage <pesan> <nomor1,nomor2,...> - Kirim pesan ke banyak kontak
!help - Tampilkan bantuan ini`);
        break;
        
      case '!creategroup':
        try {
          // Format: !creategroup NamaGrup nomor1,nomor2,nomor3,...
          const parts = args.split(' ');
          if (parts.length < 2) {
            message.reply('Format salah! Gunakan: !creategroup NamaGrup nomor1,nomor2,...');
            break;
          }
          
          const groupName = parts[0];
          const participantString = parts.slice(1).join(' ');
          const participants = participantString.split(',').map(p => p.trim() + '@c.us');
          
          if (participants.length < 1) {
            message.reply('Perlu setidaknya 1 peserta untuk membuat grup!');
            break;
          }
          
          // Buat grup baru
          message.reply(`Membuat grup "${groupName}" dengan ${participants.length} peserta...`);
          const group = await client.createGroup(groupName, participants);
          message.reply(`Grup berhasil dibuat!\nNama: ${groupName}\nID: ${group.gid._serialized}\nPeserta: ${participants.length}`);
        } catch (error) {
          console.error('Error membuat grup:', error);
          message.reply(`Error: ${error.message}`);
        }
        break;
        
      case '!bulkmessage':
        try {
          // Format: !bulkmessage Pesan nomor1,nomor2,nomor3,...
          const parts = args.split(' ');
          if (parts.length < 2) {
            message.reply('Format salah! Gunakan: !bulkmessage Pesan nomor1,nomor2,...');
            break;
          }
          
          const messageText = parts[0];
          const recipientString = parts.slice(1).join(' ');
          const recipients = recipientString.split(',').map(p => p.trim() + '@c.us');
          
          if (recipients.length < 1) {
            message.reply('Perlu setidaknya 1 penerima untuk mengirim pesan!');
            break;
          }
          
          // Kirim pesan ke semua penerima
          message.reply(`Mengirim pesan ke ${recipients.length} penerima...`);
          
          let successCount = 0;
          let failCount = 0;
          
          for (const recipient of recipients) {
            try {
              await client.sendMessage(recipient, messageText);
              successCount++;
              // Tambahkan jeda acak antara 2-5 detik untuk menghindari deteksi spam
              await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 3000));
            } catch (err) {
              console.error(`Error mengirim ke ${recipient}:`, err);
              failCount++;
            }
          }
          
          message.reply(`Pengiriman selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
        } catch (error) {
          console.error('Error mengirim pesan massal:', error);
          message.reply(`Error: ${error.message}`);
        }
        break;
        
      default:
        message.reply('Perintah tidak dikenali. Ketik !help untuk melihat perintah yang tersedia.');
    }
  }
});

// Initialize
console.log('Memulai WhatsApp Bot versi Termux...');
client.initialize().catch(error => {
  console.error('Gagal menginisialisasi WhatsApp bot:', error);
  process.exit(1);
});

// Handle exit
process.on('SIGINT', () => {
  console.log('Menutup WhatsApp bot...');
  client.destroy();
  process.exit(0);
});