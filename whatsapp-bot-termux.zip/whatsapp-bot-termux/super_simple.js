const { Client } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

// Konfigurasi client tanpa local auth (tanpa menyimpan sesi)
const client = new Client({
  puppeteer: {
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu'
    ]
  }
});

client.on('qr', (qr) => {
  console.log('Scan QR code berikut dengan WhatsApp:');
  qrcode.generate(qr, {small: true});
});

client.on('ready', () => {
  console.log('WhatsApp Bot siap digunakan!');
});

client.on('message', msg => {
  if (msg.body === '!ping') {
    msg.reply('pong');
  }
});

client.initialize();
