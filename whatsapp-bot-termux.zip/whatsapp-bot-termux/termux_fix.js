// termux_fix.js - Menghapus referensi ke /storage/emulated
const fs = require('fs');
const path = require('path');

// Jalankan versi sederhana dengan penanganan kesalahan
try {
  console.log('Mulai menjalankan WhatsApp Bot (Termux Compatible)');
  // Gunakan path relatif untuk semua file
  require('./termux_simple.js');
} catch (error) {
  console.error('Error saat menjalankan bot:', error.message);
  console.log('\n--- SOLUSI YANG DISARANKAN ---');
  console.log('1. Pastikan Anda telah menjalankan: termux-setup-storage');
  console.log('2. Coba bersihkan file auth: rm -rf .wwebjs_auth');
  console.log('3. Coba gunakan: pkg install -y chromium');
  console.log('4. Set variabel lingkungan: export PUPPETEER_EXECUTABLE_PATH=$(which chromium-browser)');
  console.log('5. Jalankan ulang dengan: node termux_fix.js');
}
